﻿namespace LIA_DOTNET_TEST.Data
{
    public class Database
    {
    }
}
