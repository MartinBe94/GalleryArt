namespace LIA_DOTNET_TEST.Models
{
    public class User
    {
        public int Id { get; set; }
        public string? Name { get; set; }
    }
}